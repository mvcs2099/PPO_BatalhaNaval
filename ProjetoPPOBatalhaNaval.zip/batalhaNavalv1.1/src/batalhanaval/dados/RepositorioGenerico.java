package batalhanaval.dados;


import batalhanaval.negocio.Jogador;

public interface RepositorioGenerico {
	public void adicionarJogador(Jogador jogador);
	public boolean atualizarJogador(Jogador jogador) throws PlayerNotFoundException;
	public boolean removerJogador(Jogador jogador);
	public Jogador buscarJogador(String id) throws PlayerNotFoundException;
	public String listarJogadores();
}
