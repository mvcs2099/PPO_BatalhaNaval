package batalhanaval.dados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

//Aos alunos http://www.guj.com.br/articles/7

public class Connect {
   
	private Connection con;
	private String url = "jdbc:postgresql://localhost:5432/BatalhaNaval";
	private String usuario = "postgres";
	private String senha = "1234";
	
	public Connect(){}

	public boolean conecta(){
		try {
		//	Class.forName("org.postgresql.Driver");			
			con = DriverManager.getConnection(url, usuario, senha);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	//servir� apenas para inser��es, atualiza��es e exclus�es no banco de dados
	public int executaSQL(String sql){
		try {
			Statement stmConsulta = con.createStatement();
			int resultado = stmConsulta.executeUpdate(sql);
			con.close();
			return resultado;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}
	//executa as consultas do tipo select/from
	public ResultSet executaConsultaSQL(String sql){// este metodo vai retornar um ResultSet, pois assim os metodos que o utilizarem saber�o o que fazer com ele
		
		try {
			Statement consultaSQL = this.con.createStatement();
			ResultSet resultadoConsulta= consultaSQL.executeQuery(sql);
			con.close();
			return resultadoConsulta;
			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		
	}
	public boolean desconecta(){
		try {
			con.close();
			return true;
		}
		catch (Exception e){
			e.printStackTrace();
			return false;
		}
		
	}
	
	public Connection getCon(){
		return con;
	}

}