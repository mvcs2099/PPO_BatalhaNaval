package batalhanaval.dados;

import java.sql.SQLException;

import batalhanaval.negocio.Jogador;

public class RepositorioJogadorDB implements RepositorioGenerico{
	private Connect connection;
	public RepositorioJogadorDB(){
		connection = new Connect();
	}
	@Override
	public void adicionarJogador(Jogador jogador) {
		String nome = jogador.getNome();
		int score = 0;
		String sql = "INSERT into jogadores(nome_jogador,id_jogador, pontuacao_jogador)"+"values('"+nome+"', default, '"+score+"')";
		int res = connection.executaSQL(sql);
		if(res > 0){
			System.out.println("Jogador Cadastrado com sucesso!");
		}else{
			System.out.println("Erro durante o cadastro");
		}
	}

	@Override
	public boolean atualizarJogador(Jogador jogador) {
		String nome = jogador.getNome();
		int score = jogador.getPontuacao();
		String sql = "UPDATE jogadores Set nome_jogador="+nome+", pontuacao_jogador = "+score+" WHERE id_jogador="+jogador.getId();
		int resposta = connection.executaSQL(sql);
		if(resposta>0){
			return true;
		}else{
			return false;
		}
	}
	
	@Override
	public Jogador buscarJogador(String id) {
		Jogador jogadorRetornado = null;
		String sql = "Select (nome_jogador, id_jogador, pontuacao_jogador) from jogadores where id_jogador="+id; 
		try {
			jogadorRetornado.setNome(connection.executaConsultaSQL(sql).getString(1));
			jogadorRetornado.setId(connection.executaConsultaSQL(sql).getString(2));
			jogadorRetornado.setPontuacao(Integer.parseInt(connection.executaConsultaSQL(sql).getString(3)));
			return jogadorRetornado;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
	}

	@Override
	public boolean removerJogador(Jogador jogador) {
		String id = jogador.getId();
		String sql = "DELETE FROM jogadores WHERE id_jogador = "+id;
		try {
			int resposta = connection.executaSQL(sql);
			if(resposta>0){
				return true;
			}else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}
	@Override
	public String listarJogadores() {
		String resultado="";
		String sql = "Select (nome_jogador, id_jogador, pontuacao_jogador) from jogadores"; 
		try {
			while(connection.executaConsultaSQL(sql).next()){
				resultado+= "Nome: "+connection.executaConsultaSQL(sql).getString(1)+" ID: "+connection.executaConsultaSQL(sql).getString(2)+" Pontuacao: "+connection.executaConsultaSQL(sql).getString(3)+"\n";
			}
			return resultado;
		} catch (SQLException e) {
			e.printStackTrace();
			return "Houve um erro durante a busca.\nTente Novamente Mais tarde, Idiota!";
		}
	}

}
