package batalhanaval.dados;

public class PlayerNotFoundException extends Exception {
	public PlayerNotFoundException(){
		super();
	}
}
