package batalhanaval.apresentacao;

public interface Apresentacao {
	public void mostrarMenuPrincipal();
	
}
