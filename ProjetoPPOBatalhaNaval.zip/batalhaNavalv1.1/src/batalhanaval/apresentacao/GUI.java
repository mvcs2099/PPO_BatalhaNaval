package batalhanaval.apresentacao;

import javax.swing.JOptionPane;

import batalhanaval.negocio.Fachada;
import batalhanaval.negocio.IFachada;

public class GUI implements Apresentacao{
	private IFachada fachada;
	
	public GUI() {
		this.fachada = new Fachada();
	}

	public void mostrarMenuPrincipal(){
		boolean condicaoParada = true;
		do{	
			int option = Integer.parseInt(JOptionPane.showInputDialog(null, "BATALHA NAVAL\n by Ismael Mecenas, Miguel Vitorino e T�lio Sobral\n\n\n	Digite o n�mero correspondente a op��o desejada:\n1. Iniciar Partida\n2. Ver Ranking Local\n3. Sair do Jogo"));
			switch(option){
			case 1:
				int inicio = Integer.parseInt(JOptionPane.showInputDialog(null, "BATALHA NAVAL\n by Ismael Mecenas, Miguel Vitorino e T�lio Sobral\n\n\n	Iniciar Partida:\n1. Contra a M�quina\n2. Contra outro Jogador\n3. Voltar ao menu"));
				switch(inicio){
				case 1:
					//iniciarJogoIA();
					break;
				case 2:
					//iniciar2Jogadores();
					break;
				case 3:
				}
			}
		}while(condicaoParada);
	}
}
