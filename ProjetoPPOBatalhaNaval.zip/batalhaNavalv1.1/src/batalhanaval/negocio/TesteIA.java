package batalhanaval.negocio;

public class TesteIA {

	public static void main(String[] args) {
		IA ia = new IA();
//		int [] tiro = new int [2];
//		int [][] recebidos = new int [25][2];
//		boolean rep = false;
//		for(int i = 0; i < 25; i ++){
//			tiro = ia.getTiro();
//			recebidos[i][0] = tiro[0];
//			recebidos[i][1] = tiro[1];
//			for(int e = 0; e < i; e++){
//				if(tiro[0] == recebidos[e][0] && tiro[1] == recebidos[e][1]){
//					rep = true;
//				}
//			}
//			System.out.println(tiro[0] + " , "+ tiro[1]);
//		}
//		System.out.println(rep);
//		
		System.out.println("testa barcos");
		for(int i =0; i <5; i++){
			int [] nav = ia.getNavio(i);			
			System.out.println(nav[0]+", "+nav[1]);
		}
		
			
		// pegou!

	}

}
