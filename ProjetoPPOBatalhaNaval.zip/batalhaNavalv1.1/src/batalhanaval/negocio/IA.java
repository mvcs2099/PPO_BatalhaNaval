package batalhanaval.negocio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class IA {

	Tabuleiro tabuleiroIA = new Tabuleiro();
	int acertos = 0;
	int [][] navios = new int[5][2];

	int [][] posicoes = new int[25][2];

	ArrayList <Integer> cordenadas = new ArrayList<>();

	int [] tiro = new int[2];

	public static void main(String[] args) {

	}


	public IA(){
		iniciarPosicoes();
		posicionarNavios();
	}
	
	public void setAcertos(){
		acertos++;
	}
	public int getAcertos(){
		return acertos;
	}

	public void iniciarPosicoes(){
		int j = 0;
		// arruma o array posicoes com as cordenadas ordenadas;
		for(int i = 0; i < 25; i++){
			if(i % 5 == 0)
				j++;
			posicoes[i][0] = j-1;	
			// para teste System.out.println(posicoes[i][0]);
		}
		j = 0;
		int aux = 0;
		for(int e = 0; e < 25; e++){
			if(e % 5 == 0)
				j++;
			j--;
			posicoes[e][1] = aux;
			aux++;
			if(aux == 5)
				aux = 0;
			// para teste System.out.println(posicoes[e][1]);

		}
		// arruma o arraylist cordenadas com valores de 0 a 24, para servir no indice do primeiro array;
		for(int m = 0; m < 25; m++){
			cordenadas.add(m);
		}
		Collections.shuffle(cordenadas);
	}	

	public int escolherIndex(){
		Random ran = new Random();
		return ran.nextInt(cordenadas.size());

	}


	public int[] getTiro(){

		int aux = escolherIndex();
		int indexPosicao = cordenadas.get(aux);		
		tiro[0] = posicoes[indexPosicao][0];
		tiro[1] = posicoes[indexPosicao][1];
		cordenadas.remove(aux);
		return tiro;
	}

	public void posicionarNavios(){
		Random ran = new Random();
		for(int e = 0; e < 5; e++){
			navios[e][0] = -1;
			navios[e][1] = -1;
		}
			
		for(int i = 0; i < 5; i++){			
			navios[i][0] = ran.nextInt(5);
			navios[i][1] = ran.nextInt(5);
			for(int m =0; m < i; m++){
				if(navios[m][0] == navios[i][0] && navios[m][1] == navios[i][1] ){
					i--;
				}
			}			
		}
	}
	
	public int[] getNavio(int cont){
		int [] navioAux = new int[2];
		navioAux[0] = navios[cont][0];
		navioAux[1] = navios[cont][1];
		return navioAux;
	}
	
	public String retornarTabuleiro(){
		return tabuleiroIA.retonarTabuleiro();
	}
	public void alterarTabuleiro(int [] tiro){
		tabuleiroIA.alterarTabuleiro(tiro, navios);
	}
	public int[][] getNavios(){
		return navios;
	}



}
