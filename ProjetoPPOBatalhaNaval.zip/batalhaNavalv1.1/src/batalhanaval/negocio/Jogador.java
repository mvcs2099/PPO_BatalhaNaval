package batalhanaval.negocio;

import java.util.InputMismatchException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.swing.JOptionPane;

import org.hibernate.annotations.Table;

@Entity
@Table(appliesTo = "jogadores")
public class Jogador {
	@Column(name="nome_jogador")
	private String nome;
	@Column(name="pontuacao_jogador")
	private int pontuacao;
	@Id
	@GeneratedValue
	private String id;
	public int getPontuacao() {
		return pontuacao;
	}
	
	public void setPontuacao(int pontuacao) {
		this.pontuacao = pontuacao;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	

	int acertos = 0;
	
	int posicaoTiro = 1;

	//String nome;

	int [][] navios = new int [5][2];

	int [][] tirosFeitos = new int[25][2];

	Tabuleiro tabuleiro = new Tabuleiro();

	public Jogador(){
		receberNome();
		inicializarNavios(navios);
		for(int i = 0; i < 25; i++){
			tirosFeitos[i][0] = -1;
			tirosFeitos[i][1] = -1;
		}
		

	}
	public void setAcertos(){
		acertos++;
	}
	public int getAcertos(){
		return acertos;
	}
	public void receberNome(){
		nome = JOptionPane.showInputDialog("Digite seu nome: ");
	}
	public String getNome(){
		return nome;
	}
	public int[][] getNavios(){
		return navios;
	}

	public static void inicializarNavios(int [][] navios){
		for(int i = 0; i < 5;i++){
			try{					
				navios[i][0] = Integer.parseInt(JOptionPane.showInputDialog("Digite a linha do Navio "+(i+1))) - 1;
				navios[i][1] = Integer.parseInt(JOptionPane.showInputDialog("Digite a coluna do Navio "+(i+1))) - 1;

			}catch(InputMismatchException e){
				JOptionPane.showMessageDialog(null, "Cordenada inv�lida");
				System.exit(0);					
			}catch(NumberFormatException e){
				JOptionPane.showMessageDialog(null, "Cordenada inv�lida");
				System.exit(0);
				
			}

			for(int e = 0; e < i; e++){
				if(navios[i][0] == navios[e][0] && navios[i][1] == navios[e][1]){
					JOptionPane.showMessageDialog(null, "Cordenada inv�lida");
					i--;
				}
			}
			if((navios[i][0]> 4 || navios[i][1] > 4)){
				i--;
				JOptionPane.showMessageDialog(null, "Cordenada inv�lida, insira uma nova em um intervalo de [1,5]");
			}
		}
	}

	public String retornarTabuleiro(){
		return tabuleiro.retonarTabuleiro();
	}
	public void alterarTabuleiro(int [] tiro){
		tabuleiro.alterarTabuleiro(tiro, navios);
	}
	public void setTirosFeitos(int [] tiro){
		tirosFeitos[posicaoTiro][0] = tiro[0];
		tirosFeitos[posicaoTiro][1] = tiro[1];
		this.posicaoTiro++;
		
	}
	public boolean verificarTirosFeitos(int [] tiros){
		
		for(int i = 0; i < 25; i++){
			
			if(tirosFeitos[i][0] == tiros[0] && tirosFeitos[i][1] == tiros[1])
				return false;
		}
		return true;
	}
	
}
