package batalhanaval.negocio;

import batalhanaval.dados.PlayerNotFoundException;

public interface IFachada {
	public void inserir(Jogador jogador);
	public void alterar(Jogador jogador) throws PlayerNotFoundException;
	public void remover(Jogador jogador);
	public Jogador buscar(String id) throws PlayerNotFoundException;
}
