package batalhanaval.negocio;

import batalhanaval.dados.PlayerNotFoundException;
import batalhanaval.dados.RepositorioGenerico;
import batalhanaval.dados.RepositorioJogadorDB;

public class ControladorJogador {
	private RepositorioGenerico repositorioJogador;
	public ControladorJogador(){
		repositorioJogador = new RepositorioJogadorDB();
	}
	//adicionar
	public void adicionarJogador(Jogador jogador){
		this.repositorioJogador.adicionarJogador(jogador);
	}
	//buscar
	public Jogador buscarJogador(String id) throws PlayerNotFoundException{
		return this.repositorioJogador.buscarJogador(id);
	}
	//alterar
	public boolean alterarJogador(Jogador jogador) throws PlayerNotFoundException{
		return this.repositorioJogador.atualizarJogador(jogador);
	}
	//remover
	public void removerJogador(Jogador jogador){
		this.repositorioJogador.removerJogador(jogador);
	}
}
