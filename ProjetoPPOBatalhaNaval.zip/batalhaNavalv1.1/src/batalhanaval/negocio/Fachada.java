package batalhanaval.negocio;

import batalhanaval.dados.PlayerNotFoundException;

public class Fachada implements IFachada{
	private ControladorJogador ctrlJogador;
	@Override
	public void inserir(Jogador jogador) {
		// TODO Auto-generated method stub
		this.ctrlJogador.adicionarJogador(jogador);
	}

	@Override
	public void alterar(Jogador jogador) throws PlayerNotFoundException {
		// TODO Auto-generated method stub
		this.ctrlJogador.alterarJogador(jogador);
	}

	@Override
	public void remover(Jogador jogador) {
		// TODO Auto-generated method stub
		this.ctrlJogador.removerJogador(jogador);
	}

	@Override
	public Jogador buscar(String id) throws PlayerNotFoundException {
		// TODO Auto-generated method stub
		return this.ctrlJogador.buscarJogador(id);
	}

}
