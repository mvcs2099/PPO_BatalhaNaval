package batalhanaval.negocio;

import java.util.InputMismatchException;
import java.util.Random;
import javax.swing.JOptionPane;


public class Partida {
	public static void main(String[] args) {
		boolean condicao = true;
		do{
			switch(Integer.parseInt((JOptionPane.showInputDialog("Batalha Naval\n1. Iniciar PvP\n2. Iniciar PvM\n3. Visualizar Estat�sticas\n0. Sair")))){
		
			case 1:
				iniciar2Jogadores();
				break;
			case 2:
				iniciarJogoIA();
				break;
			case 3:
				visualizarStats();
				break;
			case 0: 
				condicao = false;
				break;
			}
		}while(condicao);
		//M�TODO PRINCIAL � ESSE MAIN
		//descomente a linha abaixo para jogar contra outra pessoa, com o bug das cordenadas e dos tiros repetidos RESOLVIDOS!!
		//
		//descomente a linha abaixo para jogar contra a IA.
		//iniciarJogoIA();

	}
	public static void visualizarStats(){
		
	}
	public static void iniciarJogoIA(){
		IA ia = new IA();		
		Jogador jog = new Jogador();
		boolean paradaI = true;
		Random ran = new Random();
		int vez = ran.nextInt(2) + 1;
		int [] tiro = new int[2];
		while(paradaI){
			JOptionPane.showMessageDialog(null, "Tabuleiro de " + jog.getNome() + "\n" + jog.retornarTabuleiro() + "\n"
					+ "Tabuleiro da M�quina\n" + ia.retornarTabuleiro());
			if(vez%2 == 1){
				JOptionPane.showMessageDialog(null, "Vez de " + jog.getNome());
				darTiro(tiro);
				if(jog.verificarTirosFeitos(tiro)){
					vez++;
					jog.setTirosFeitos(tiro);
					ia.alterarTabuleiro(tiro);
					if(acertou(tiro,ia.getNavios())){
						vez--;
						jog.setAcertos();					
					}
				}else{
					JOptionPane.showMessageDialog(null, "Cordenada inv�lida! Tente de novo.");
				}
			} else if(vez%2 == 0){
				JOptionPane.showMessageDialog(null, "Vez da m�quina");
				vez++;
				tiro = ia.getTiro();
				jog.alterarTabuleiro(tiro);
				if(acertou(tiro,jog.getNavios())){
					vez--;
					ia.setAcertos();					
					//JOptionPane.showMessageDialog(null,"Voc� acertou o tiro ("+(tiro[0]+1)+","+(tiro[1]+1)+") !!");
				}

			}
			if(jog.getAcertos() == 5){
				JOptionPane.showMessageDialog(null, "Tabuleiro de " + jog.getNome() + "\n" + jog.retornarTabuleiro() + "\n"
						+ "Tabuleiro da m�quina\n" + ia.retornarTabuleiro());
				paradaI = false;
				//setNomeVencedor(jog.getNome());
				JOptionPane.showMessageDialog(null, "O vencedor foi "+ jog.getNome());
			}
			if(ia.getAcertos() == 5){
				JOptionPane.showMessageDialog(null, "Tabuleiro de " + jog.getNome() + "\n" + jog.retornarTabuleiro() + "\n"
						+ "Tabuleiro da m�quina\n" + ia.retornarTabuleiro());
				paradaI = false;
				JOptionPane.showMessageDialog(null, "O vencedor foi a m�quina");
			}

		}

	}

	public static void iniciar2Jogadores(){

		boolean parada = true;

		int [] tiro = new int[2];

		JOptionPane.showMessageDialog(null,"Jogador 1");
		Jogador jog1 = new Jogador();

		JOptionPane.showMessageDialog(null,"Jogador 2");
		Jogador jog2 = new Jogador();


		Random ran = new Random();
		int vez = ran.nextInt(2) + 1;

		while(parada){
			//o jogo ocorre dentro desse while
			JOptionPane.showMessageDialog(null, "Tabuleiro de " + jog1.getNome() + "\n" + jog1.retornarTabuleiro() + "\n"
					+ "Tabuleiro de " + jog2.getNome() + "\n" + jog2.retornarTabuleiro());
			if(vez%2 == 1){
				JOptionPane.showMessageDialog(null, "Vez de " + jog1.getNome());
				darTiro(tiro);
				if(jog1.verificarTirosFeitos(tiro)){
					vez++;
					jog1.setTirosFeitos(tiro);
					jog2.alterarTabuleiro(tiro);
					if(acertou(tiro,jog2.getNavios())){
						vez--;
						jog1.setAcertos();					
						//JOptionPane.showMessageDialog(null,"Voc� acertou o tiro ("+(tiro[0]+1)+","+(tiro[1]+1)+") !!");
					}
				}else{
					JOptionPane.showMessageDialog(null, "Cordenada inv�lida! Tente de novo.");
				}
			} else if(vez%2 == 0){
				JOptionPane.showMessageDialog(null, "Vez de " + jog2.getNome());
				darTiro(tiro);
				if(jog2.verificarTirosFeitos(tiro)){
					vez++;
					jog2.setTirosFeitos(tiro);
					jog1.alterarTabuleiro(tiro);
					if(acertou(tiro,jog1.getNavios())){
						vez--;
						jog2.setAcertos();					
						//JOptionPane.showMessageDialog(null,"Voc� acertou o tiro ("+(tiro[0]+1)+","+(tiro[1]+1)+") !!");
					}
				}else{
					JOptionPane.showMessageDialog(null, "Cordenada inv�lida! Tente de novo.");	
				}
			}
			if(jog1.getAcertos() == 5){
				JOptionPane.showMessageDialog(null, "Tabuleiro de " + jog1.getNome() + "\n" + jog1.retornarTabuleiro() + "\n"
						+ "Tabuleiro de " + jog2.getNome() + "\n" + jog2.retornarTabuleiro());
				parada = false;
				JOptionPane.showMessageDialog(null, "O vencedor foi "+ jog1.getNome());
			}
			if(jog2.getAcertos() == 5){
				JOptionPane.showMessageDialog(null, "Tabuleiro de " + jog1.getNome() + "\n" + jog1.retornarTabuleiro() + "\n"
						+ "Tabuleiro de " + jog2.getNome() + "\n" + jog2.retornarTabuleiro());
				parada = false;
				JOptionPane.showMessageDialog(null, "O vencedor foi "+ jog2.getNome());
			}
			//parada = false;

		}		
	}

	public static void darTiro(int[] tiro){
		boolean condicaotiro = true;
		try{
			while(condicaotiro){
				tiro[0] = Integer.parseInt(JOptionPane.showInputDialog("Cordenadas para o tiro\nLinha: "));	
				tiro[0]--;

				tiro[1] = Integer.parseInt(JOptionPane.showInputDialog("Cordenadas para o tiro\nColuna: "));
				tiro[1]--;
				if(tiro[0] > 4 || tiro[1] > 4 || tiro[1] < 0 || tiro[0] < 0){
					JOptionPane.showMessageDialog(null, "Tiro inv�lido! Tente de novo.");
				}else{
					condicaotiro = false;
				}
			}
		}
		catch(InputMismatchException e){
			JOptionPane.showMessageDialog(null, "Tiro inv�lido! Tente de novo.");
			darTiro(tiro);
		}catch(NumberFormatException e){
			JOptionPane.showMessageDialog(null, "Tiro inv�lido! Tente de novo.");
			darTiro(tiro);
		}

	}

	public static boolean acertou(int[] tiro, int[][] navios){

		for(int navio = 0 ; navio<navios.length ; navio++){
			if( tiro[0]==navios[navio][0] && tiro[1]==navios[navio][1]){			
				return true;
			}
		}
		return false;
	}


	public boolean verificarTirosFeitos(Jogador J, int [] tiros){
		return J.verificarTirosFeitos(tiros);

	}
	// o m�todo acertou est� presente na classe tabuleiro e na classe partiida

}
