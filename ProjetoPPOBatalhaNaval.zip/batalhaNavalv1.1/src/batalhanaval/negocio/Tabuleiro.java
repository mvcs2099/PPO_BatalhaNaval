package batalhanaval.negocio;

public class Tabuleiro {
	
	static int tamTabuleiro = 10;
	
	int [][] tabuleiro = new int [tamTabuleiro][tamTabuleiro];
	
	static String matComp = "";
	
	public Tabuleiro(){
		montarTab(tabuleiro);		
	}
	
	public static void montarTab(int [][] tab){
		//preenche matriz
		int aux = 0;
		for(int i = 0; i < tamTabuleiro; i++){
			for(int e = 0; e < tamTabuleiro; e++){
				tab[i][e] = aux;

			}
		}
	}
	public static boolean acertou(int[] tiro, int[][] navios ){
		for(int navio = 0 ; navio<navios.length ; navio++){
			if( tiro[0]==navios[navio][0] && tiro[1]==navios[navio][1]){			
				return true;
			}
		}
		return false;
	}
	
	public void alterarTabuleiro(int[] tiro, int[][] navios){
		if(acertou(tiro,navios))
			this.tabuleiro[tiro[0]][tiro[1]]=2;
		else
			this.tabuleiro[tiro[0]][tiro[1]]=1;
	}
	
	public static void mostrarTab(int [][] tab){
		//mostra cordenada
		matComp = "";
		String cordMudada = "";
		for(int i = 1; i <= tamTabuleiro; i++){
			cordMudada = "   "+ (tamTabuleiro+1-i) + cordMudada;
		}
		cordMudada = "  " + cordMudada;
		//System.out.println(cordMudada);
		//System.out.println("\n   1   2   3   4   5   6   7   8   9   10 ");

		//mostramatriz
		String mat = " | ";

		int cordL = 1;
		
		for(int i = 0; i < tamTabuleiro; i++){
			for(int e = 0; e < tamTabuleiro; e++){
				if(tab[i][e] == 0){
					mat = mat + "~" + " | ";
				}
				else if(tab[i][e] == 1){
					mat = mat + "O" + " | ";
				}else{
					mat = mat + "X" + " | ";
				}
			}
			mat = cordL + mat + "\n";
			matComp = matComp + mat;
			
			cordL++;
			if(i != 8){
				mat = " | ";
			}else{
				mat = "|";
			}
		}
		matComp = cordMudada + "\n" + matComp;
		//System.out.println(matComp);

	}
	public String retonarTabuleiro(){
		mostrarTab(tabuleiro);
		return matComp;		
	}
	public int [][] getTabuleiro(){
		return tabuleiro;
	}

	

}
